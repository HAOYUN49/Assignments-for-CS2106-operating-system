/*************************************
 * Lab 4 Exercise N
 * Name: HAO YUN
 * Student No: A0177907N
 * Lab Group: 08
 *************************************/

// You can modify anything in this file. 
// Unless otherwise stated, a line of code being present in this template 
//  does not imply that it is correct/necessary! 
// You can also add any global or local variables you need (e.g. to implement your page replacement algorithm).

#include <signal.h>
#include <stdlib.h>

#include "api.h"

typedef struct {
    unsigned int page_index;
    unsigned int valid;
} frame_entry;

void os_run(int initial_num_pages, page_table *pg_table){
    // The main loop of your memory manager
    sigset_t signals;
    sigemptyset(&signals);
    sigaddset(&signals, SIGUSR1);
    
    // create the pages in the disk first, because every page must be backed by the disk for this lab
    for (int i=0; i!=initial_num_pages; ++i) {
        disk_create(i);
    }
    
    int frame_num = 1<<FRAME_BITS;
    frame_entry *frames = malloc(sizeof(frame_entry)*frame_num);
    int next_victim = 0;
    int frame_page;

    for (int i = 0; i < frame_num; i++) {
        frames[i].valid = 0;
    }
    while (1) {
        siginfo_t info;
        sigwaitinfo(&signals, &info);
        union sigval reply_value;
        reply_value.sival_int = 0;
        
        // retrieve the index of the page that the user program wants, or -1 if the user program has terminated
        int const requested_page = info.si_value.sival_int;
        
        if (requested_page == -1) break;
        if (requested_page >= initial_num_pages) {
            reply_value.sival_int = 1;
            sigqueue(info.si_pid, SIGCONT, reply_value);
            continue;
        }
        
        // process the signal, and update the page table as necessary
        while(1) {
            if(!frames[next_victim].valid) break;
            frame_page = frames[next_victim].page_index;
            if(pg_table->entries[frame_page].referenced == 0) {
                pg_table->entries[frame_page].valid = 0;
                break;
            }
            pg_table->entries[frame_page].referenced = 0;
            next_victim = (next_victim+1)%frame_num;
        }
        
        if(frames[next_victim].valid && pg_table->entries[frame_page].dirty == 1) {
            pg_table->entries[frame_page].dirty = 0;
            disk_write(next_victim,frame_page);
        }
        
        disk_read(next_victim, requested_page);
        pg_table->entries[requested_page].valid = 1;
        pg_table->entries[requested_page].frame_index = next_victim;
        frames[next_victim].page_index = requested_page;
        frames[next_victim].valid = 1;
        next_victim = (next_victim+1)%frame_num;
        
        // tell the MMU that we are done updating the page table
        sigqueue(info.si_pid, SIGCONT, reply_value);
    }
    free(frames);
}
    
